package com.foxconn.dcc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DccApplicationTests {

    @Test
    void contextLoads() {
    }

}
