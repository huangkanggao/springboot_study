package com.foxconn.dcc.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foxconn.dcc.model.BaseRoleInfo;
import com.foxconn.dcc.model.BaseUserInfo;
import com.foxconn.dcc.service.UserService;
import com.foxconn.dcc.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * @author rookie
 * @date 2020/4/27 下午1:56
 * @description： TODO
 * @modifiedBy：
 */
@Slf4j
@RestController
@RequestMapping("/api/users/v1")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @PostMapping(value = "/login",produces = {"application/json;charset=UTF-8"})
    public Object login(@RequestBody String json)  {

        System.out.println("进来了请求");
       JSONObject jsonObject= (JSONObject) JSON.parse(json);
       String emp_no=jsonObject.getString("emp_no");
       String password=jsonObject.getString("password");
       BaseUserInfo baseUserInfo= userService.getUserByEmpNo(emp_no);
       JSONObject jsonObject_two=new JSONObject();
       if (null==baseUserInfo){
           jsonObject_two.put("userStatus","404");
           jsonObject_two.put("message","登录失败,用户不存在");

           return jsonObject_two;
       }
       else {
           if(!baseUserInfo.getPassword().equals(password)){
               jsonObject_two.put("userStatus","404");
            jsonObject_two.put("message","登录失败,密码错误");
            return jsonObject;
           }else {
               //生成token,并把token返回给前端
               String token= jwtTokenUtil.generateToken(baseUserInfo);
               //获取当前用户的角色
                BaseRoleInfo baseRoleInfo= userService.getRoleByEmpNo(emp_no);
               jsonObject_two.put("userStatus","200");
               jsonObject_two.put("token",token);
                jsonObject_two.put("empNo",emp_no);
                jsonObject_two.put("roleCode",baseRoleInfo.getCode());
                return jsonObject_two;
           }
       }

    }

    @GetMapping(value = "/play_data")
    public String loginPlay()  {
            return "playData";

    }
}
