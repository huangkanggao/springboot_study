package com.foxconn.dcc.config;

import com.foxconn.dcc.interceptor.TokenInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author rookie
 * @date 2020/4/27 下午2:44
 * @description： TODO
 * @modifiedBy：
 */
@Configuration
public class InterceptorConfig implements WebMvcConfigurer {
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
//        除了页面渲染的请求和登录的请求,其它都要通过token验证
        registry.addInterceptor(tokenInterceptor())
                .addPathPatterns("/**").excludePathPatterns("/static/**","/","/api/users/v1/login");
    }
    @Bean
    public TokenInterceptor tokenInterceptor() {
        return new TokenInterceptor();
    }

}
