package com.foxconn.dcc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author rookie
 * @date 2020/4/27 上午11:23
 * @description： TODO
 * @modifiedBy：
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaseUserInfo implements Serializable {
    private Integer id;
    private String username;
    private String empNo;
    private String email;
    private String password;
    private Integer active;
    private String remarks;
    private Date createTime;
    private Date updateTime;

    private BaseRoleInfo baseRoleInfo;


}
