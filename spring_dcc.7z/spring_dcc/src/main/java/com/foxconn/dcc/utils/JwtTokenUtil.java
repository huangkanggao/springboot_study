package com.foxconn.dcc.utils;

import com.foxconn.dcc.model.BaseUserInfo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author rookie
 * @date 2020/4/27 下午2:11
 * @description： TODO
 * @modifiedBy：
 */
@Component
public class JwtTokenUtil implements Serializable {

    private static final String CLAIM_KEY_USERNAME = "sub";

    /**
     * 1000*60*60*2(毫秒)目前设定过期时间为2小时
     */
    private static final long EXPIRATION_TIME = 30000;
    /**
     * JWT密码
     */
    private static final String SECRET = "foxDCC2020";



    /**
     * 签发JWT
     */
    public String generateToken(BaseUserInfo baseUserInfo) {
        Map<String, Object> claims = new HashMap<>(16);
        claims.put( CLAIM_KEY_USERNAME, baseUserInfo.getEmpNo() );
        return Jwts.builder()
                .setClaims( claims )
                .setExpiration( new Date( Instant.now().toEpochMilli() + EXPIRATION_TIME  ) )
                .signWith( SignatureAlgorithm.HS512, SECRET )
                .compact();
    }

    /**
     * 验证JWT
     */
    public Boolean validateToken(String token, BaseUserInfo baseUserInfo) {
        String empNo = getEmpNoFromToken( token );
        return (empNo.equals( baseUserInfo.getEmpNo() ) && !isTokenExpired( token ));
    }

    /**
     * 获取token是否过期
     */
    public Boolean isTokenExpired(String token) {
        try {
            Date expiration = getExpirationDateFromToken( token );
            return expiration.before( new Date() );
        }catch (Exception exception){
            return true;
        }

    }

    /**
     * 根据token获取empNo
     */
    public String getEmpNoFromToken(String token) {
        String empNo = getClaimsFromToken( token ).getSubject();
        return empNo;
    }

    /**
     * 获取token的过期时间
     */
    public Date getExpirationDateFromToken(String token) {
        Date expiration = getClaimsFromToken( token ).getExpiration();
        return expiration;
    }

    /**
     * 解析JWT
     */
    private Claims getClaimsFromToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey( SECRET )
                .parseClaimsJws( token )
                .getBody();
        return claims;
    }

}
