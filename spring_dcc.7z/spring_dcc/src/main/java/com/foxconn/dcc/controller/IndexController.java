package com.foxconn.dcc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author rookie
 * @date 2020/4/27 上午11:37
 * @description： TODO
 * @modifiedBy：
 */
@Controller
public class IndexController {
    @RequestMapping("/")
    public String indexPage(Model model){
        return "index";
    }



}
