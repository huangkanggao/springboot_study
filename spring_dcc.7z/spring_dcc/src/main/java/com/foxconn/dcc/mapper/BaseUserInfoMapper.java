package com.foxconn.dcc.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foxconn.dcc.model.BaseRoleInfo;
import com.foxconn.dcc.model.BaseUserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

/**
 * @author rookie
 * @date 2020/4/27 上午11:31
 * @description： TODO
 * @modifiedBy：
 */
@Mapper
@Component
public interface BaseUserInfoMapper extends BaseMapper<BaseUserInfo> {

    /**
     * 根据工号查看这个人是否存在
     */
    @Select("SELECT * FROM bas_user_info WHERE emp_no=#{emp_no}")
    BaseUserInfo getUserByEmpNo(@Param("emp_no") String emp_no);

    @Select("SELECT bri.* FROM bas_user_info bui INNER JOIN rel_user_role rur ON bui.id=rur.user_id INNER JOIN bas_role_info bri ON rur.role_id=bri.id WHERE \n" +
            " bui.active=1 AND rur.active=1 AND bri.active=1 AND emp_no=#{emp_no}")
    BaseRoleInfo getRoleByEmpNo(@Param("emp_no") String emp_no);
}
