package com.foxconn.dcc.interceptor;

import com.foxconn.dcc.service.UserService;
import com.foxconn.dcc.utils.JwtTokenUtil;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.NestedServletException;

/**
 * @author rookie
 * @date 2020/4/27 下午2:25
 * @description： TODO
 * @modifiedBy：
 */
@Slf4j
public class TokenInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    /**
     * 存放Token的Header Key
     */
    public static final String HEADER_STRING = "Authorization";

    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object object) throws Exception {

        try {
            //获取头部的token
            String token = httpServletRequest.getHeader(HEADER_STRING);
            //假如取不到token
            if (token == null) {
                httpServletResponse.setStatus(201);
                httpServletResponse.setContentType("参数无token");
                return false;
            }
            //通过token获取emp_no
            String emp_no = jwtTokenUtil.getEmpNoFromToken(token);
            //验证token

            boolean flag= jwtTokenUtil.validateToken(token,userService.getUserByEmpNo(emp_no));

            if (flag==false){
                httpServletResponse.setStatus(202);
                httpServletResponse.setContentType("token验证错误");
                return false;
            }
            else {
                return true;
            }
        }
        catch (MalformedJwtException malformedJwtException){
            httpServletResponse.setStatus(202);
            httpServletResponse.setContentType("token验证错误");
            return false;
        }
        catch (ExpiredJwtException eje) {
            httpServletResponse.setStatus(203);
            httpServletResponse.setContentType("token失效");
            return false;
        }


    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }
    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
