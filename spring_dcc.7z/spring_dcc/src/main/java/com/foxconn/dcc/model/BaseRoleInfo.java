package com.foxconn.dcc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @author rookie
 * @date 2020/4/27 下午3:53
 * @description： TODO
 * @modifiedBy：
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BaseRoleInfo implements Serializable {
    private Integer id;
    private String code;
    private String name;
    private Integer active;
    private String remarks;
    private Date createTime;
    private Date updateTime;
}
