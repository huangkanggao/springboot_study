package com.foxconn.dcc.service;


import com.foxconn.dcc.mapper.BaseUserInfoMapper;
import com.foxconn.dcc.model.BaseRoleInfo;
import com.foxconn.dcc.model.BaseUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author rookie
 * @date 2020/4/27 上午11:38
 * @description： TODO
 * @modifiedBy：
 */
@Slf4j
@Service
public class UserService {
    @Autowired
    private BaseUserInfoMapper baseUserInfoMapper;

    /**
     * 根据工号查看这个人是否存在
     */

    public BaseUserInfo getUserByEmpNo(String emp_no) {
        return baseUserInfoMapper.getUserByEmpNo(emp_no);
    }

    public BaseRoleInfo getRoleByEmpNo(String emp_no) {
        return baseUserInfoMapper.getRoleByEmpNo(emp_no);
    }

}
